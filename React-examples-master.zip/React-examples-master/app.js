// let renderer = require("./src/renderer"); let loginApp =
// require('./login/renderer');
require("./imageUploader/renderer");