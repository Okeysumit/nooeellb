import React from "react";
import ReactDOM from "react-dom";

import DraggableUploader from "./draggableUploader";

ReactDOM.render(
  <DraggableUploader/>, document.getElementById("root"));