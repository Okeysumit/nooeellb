```rb
# Gemfile
gem "sprockets"
gem "sprockets-bumble_d"
```

```sh
bundle install
npm install --save @babel/core @babel/plugin-external-helpers @babel/plugin-transform-modules-umd @babel/preset-env
```
