```sh
npm install --save-dev broccoli-babel-transpiler
```
