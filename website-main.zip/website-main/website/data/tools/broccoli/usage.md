```js
var babelTranspiler = require("broccoli-babel-transpiler");
var scriptTree = babelTranspiler(inputTree, options);
```

<blockquote class="babel-callout babel-callout-info">
  <p>
    For more information see the <a href="https://github.com/babel/broccoli-babel-transpiler">babel/broccoli-babel-transpiler repo</a>.
  </p>
</blockquote>

