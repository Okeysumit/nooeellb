```sh
npm install --save-dev requirejs-babel @babel/standalone babel-plugin-module-resolver-standalone
```
