```sh
npm install @babel/register
```
