```sh
npm install babel-connect
```
