`jstransformer-babel` supports Babel 6 only.

```sh
npm install jstransformer-babel
```
