```sh
babel-node-debug path/to/script.js
```

Or use the alias:

```sh
bode-debug path/to/script.js
```

<blockquote class="babel-callout babel-callout-info">
  <p>
    For more information see the <a href="https://github.com/crabdude/babel-node-debug">crabdude/babel-node-debug repo</a>.
  </p>
</blockquote>

