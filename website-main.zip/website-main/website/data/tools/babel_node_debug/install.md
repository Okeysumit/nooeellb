```sh
npm install -g babel-node-debug
```
