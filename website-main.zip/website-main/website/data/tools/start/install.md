```sh
npm install -D @start/plugin-lib-babel
```
