```sh
npm install --save-dev babel-loader @babel/core
```
