```sh
npm install --save-dev karma-babel-preprocessor @babel/core
```
