```sh
npm install --save-dev @babel/register @babel/core
```
