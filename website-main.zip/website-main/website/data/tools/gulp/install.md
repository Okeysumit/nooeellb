```sh
# Babel 7
npm install --save-dev gulp-babel @babel/core
```
