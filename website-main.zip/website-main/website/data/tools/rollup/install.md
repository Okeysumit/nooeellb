```sh
npm install --save-dev @rollup/plugin-babel @babel/core
```
