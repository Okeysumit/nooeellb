```sh
npm install --save-dev @ava/babel
```
