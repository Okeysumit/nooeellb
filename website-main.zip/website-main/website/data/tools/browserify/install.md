```sh
npm install --save-dev babelify @babel/core
```
