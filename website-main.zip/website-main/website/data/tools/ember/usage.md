That's it!

<blockquote class="babel-callout babel-callout-info">
  <p>
    For more information see the <a href="https://github.com/babel/ember-cli-babel">babel/ember-cli-babel repo</a>.
  </p>
</blockquote>

