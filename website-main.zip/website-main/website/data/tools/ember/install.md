```sh
ember install ember-cli-babel
```
