```sh
npm install --save-dev sails-hook-babel
```
