Support for Babel in ASP.NET 4.x is provided by the [ReactJS.NET](http://reactjs.net/) project. Install the MSBuild task via NuGet:

```
Install-Package React.MSBuild
```
