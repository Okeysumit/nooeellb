```sh
npm install --save-dev lab-babel
```
