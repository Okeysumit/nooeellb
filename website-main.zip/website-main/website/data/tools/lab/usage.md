When running tests with [`lab`](https://www.npmjs.com/package/lab) set the transpiler to [`lab-babel`](https://www.npmjs.com/package/lab-babel):

```sh
lab -T node_modules/lab-babel
```
