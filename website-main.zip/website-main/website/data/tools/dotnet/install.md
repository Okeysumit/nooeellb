Support for Babel in .NET is provided by the [ReactJS.NET](http://reactjs.net/) project. The core library can be installed via NuGet:

```
Install-Package React.Core
```
