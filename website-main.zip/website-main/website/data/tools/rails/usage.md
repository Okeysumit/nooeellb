That's it!

<blockquote class="babel-callout babel-callout-info">
  <p>
    For more information see the <a href="https://github.com/rails/webpacker">rails/webpacker repo</a>.
  </p>
</blockquote>

Alternatively, if you need babel to transpile javascript that's processed
through <a href="https://github.com/rails/sprockets">sprockets</a>, refer to the
setup instructions for
<a href="#installation" onclick="event.preventDefault(); document.querySelector('.tools-button[data-title=sprockets]').click()">integrating babel with sprockets</a>.