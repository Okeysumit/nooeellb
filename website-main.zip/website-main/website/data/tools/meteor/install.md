As of Meteor 1.2, the `ecmascript` package is installed by default for all
new apps.

```sh
meteor add ecmascript
```
