```sh
gem install babel-transpiler
```
