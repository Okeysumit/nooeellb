```ruby
require 'babel/transpiler'
Babel::Transpiler.transform File.read("foo.es6")
```

<blockquote class="babel-callout babel-callout-info">
  <p>
    For more information see the <a href="https://github.com/babel/ruby-babel-transpiler">babel/ruby-babel-transpiler repo</a>.
  </p>
</blockquote>
