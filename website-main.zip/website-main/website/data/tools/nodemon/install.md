```sh
npm install @babel/core @babel/node --save-dev
```
