```sh
npm install --save-dev @babel/cli
```
