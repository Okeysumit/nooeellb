```sh
npm install --save-dev duo-babel
```
