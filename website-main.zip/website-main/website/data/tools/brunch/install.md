```sh
npm install --save-dev babel-brunch
```
