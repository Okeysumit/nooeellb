Babel will automatically be used when loading any source with `import` or `export` module syntax.

<blockquote class="babel-callout babel-callout-info">
  <p>
    JSX support is currently disabled by jspm. To re-enable it, add `"blacklist": []` to `babelOptions` in the jspm configuration file.
  </p>
</blockquote>
