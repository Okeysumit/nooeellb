Select `babel` as the transpiler when running `jspm init -p` or to switch an existing project into Babel use:

```sh
jspm dl-loader --babel
```

<blockquote class="babel-callout babel-callout-warning">
  <p>
    The jspm package management CLI has been deprecated as of June 2020. See <a href="https://github.com/jspm/jspm-cli">jspm repo</a> for more details.
  </p>
</blockquote>
