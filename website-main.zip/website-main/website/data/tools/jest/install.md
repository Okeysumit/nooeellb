`babel-jest` is now automatically loaded by Jest and fully integrated. This step is only required if you are using `babel-jest` to transform TypeScript files.
```sh
npm install --save-dev babel-jest
```
