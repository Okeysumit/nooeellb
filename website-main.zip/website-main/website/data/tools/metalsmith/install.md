```sh
npm install metalsmith-babel
```
