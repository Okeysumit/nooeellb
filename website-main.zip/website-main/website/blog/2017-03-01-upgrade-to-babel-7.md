---
layout: post
title:  "Upgrade to Babel 7 (moved)"
author: Sven SAULEAU, Henry Zhu
date:   2017-02-29 11:00:00
categories: announcements
share_text: "Upgrade to Babel 7"
third_party_js:
- https://platform.twitter.com/widgets.js
custom_js_with_timestamps:
- docs.js
---

We are moving the migration guide to a docs page instead of a blog post!

## Check out [v7-migration](https://babeljs.io/docs/en/next/v7-migration)!
