---
id: babel-helper-builder-binary-assignment-operator-visitor
title: @babel/helper-builder-binary-assignment-operator-visitor
sidebar_label: helper-builder-binary-assignment-operator-visitor
---

TODO

