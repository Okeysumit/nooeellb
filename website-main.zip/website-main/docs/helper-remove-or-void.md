---
id: babel-helper-remove-or-void
title: babel-helper-remove-or-void
sidebar_label: babel-helper-remove-or-void
---

```sh
npm install babel-helper-remove-or-void --save-dev
```

