---
title: .babelrc
id: babelrc
---

This documentation has been moved to [file-relative configuration docs](config-files.md#file-relative-configuration).
