---
id: babel-helper-mark-eval-scopes
title: babel-helper-mark-eval-scopes
sidebar_label: babel-helper-mark-eval-scopes
---

## Installation

```sh
npm install babel-helper-mark-eval-scopes --save-dev
```

