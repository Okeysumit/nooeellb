---
id: babel-helper-flip-expressions
title: babel-helper-flip-expressions
sidebar_label: babel-helper-flip-expressions
---

```sh
npm install babel-helper-flip-expressions --save-dev
```

