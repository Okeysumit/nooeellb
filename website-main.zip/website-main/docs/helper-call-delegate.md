---
id: babel-helper-call-delegate
title: @babel/helper-call-delegate
sidebar_label: helper-call-delegate
---

TODO

