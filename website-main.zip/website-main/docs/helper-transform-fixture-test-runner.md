---
id: babel-helper-transform-fixture-test-runner
title: @babel/helper-transform-fixture-test-runner
sidebar_label: helper-transform-fixture-test-runner
---

## Usage

```javascript
import runFixtures from "@babel/helper-transform-fixture-test-runner";

runFixtures("/User/sebmck/Projects/babel-something/test/fixtures");
```

