---
id: babel-helper-explode-assignable-expression
title: @babel/helper-explode-assignable-expression
sidebar_label: helper-explode-assignable-expression
---

TODO

