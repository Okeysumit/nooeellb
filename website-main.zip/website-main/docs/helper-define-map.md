---
id: babel-helper-define-map
title: @babel/helper-define-map
sidebar_label: helper-define-map
---

TODO

