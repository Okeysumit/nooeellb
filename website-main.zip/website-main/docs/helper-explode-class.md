---
id: babel-helper-explode-class
title: @babel/helper-explode-class
sidebar_label: helper-explode-class
---

TODO

