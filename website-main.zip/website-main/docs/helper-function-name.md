---
id: babel-helper-function-name
title: @babel/helper-function-name
sidebar_label: helper-function-name
---

TODO

