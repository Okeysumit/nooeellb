---
title: babel.config.js
id: babelconfigjs
---

This documentation has been moved to [project-wide configuration docs](config-files.md#project-wide-configuration).
