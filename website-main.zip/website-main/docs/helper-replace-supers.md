---
id: babel-helper-replace-supers
title: @babel/helper-replace-supers
sidebar_label: helper-replace-supers
---

TODO

