---
id: babel-helper-optimise-call-expression
title: @babel/helper-optimise-call-expression
sidebar_label: helper-optimise-call-expression
---

TODO

