---
id: babel-helper-to-multiple-sequence-expressions
title: babel-helper-to-multiple-sequence-expressions
sidebar_label: babel-helper-to-multiple-sequence-expressions
---

```sh
npm install babel-helper-to-multiple-sequence-expressions --save-dev
```

