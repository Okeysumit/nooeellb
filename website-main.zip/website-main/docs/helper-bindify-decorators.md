---
id: babel-helper-bindify-decorators
title: @babel/helper-bindify-decorators
sidebar_label: helper-bindify-decorators
---

```js
declare export default bindifyDecorators(decorators: Array<NodePath>);
```
## Usage

TODO

