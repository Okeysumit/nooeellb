export { EditorState, basicSetup } from "@codemirror/basic-setup";
export { EditorView } from "@codemirror/view";
export { oneDark } from "@codemirror/theme-one-dark";
export { javascriptLanguage } from "@codemirror/lang-javascript";
